#!/usr/bin/env python3
"""Coletor e analisador do painel de combustíveis.

Roda 1x por dia (GitHub Actions). Faz:
  1. busca Brent, RBOB (gasolina intl), Heating Oil (diesel intl) e dólar;
  2. lê os valores manuais (manual.json): etanol Cepea e preços internos;
  3. grava data/historico.csv (histórico permanente);
  4. calcula variações, tendência, projeção e a recomendação de compra;
  5. grava docs/dados.json, que o site (docs/index.html) lê.

Só usa a biblioteca padrão do Python: nada para instalar.
"""
import csv
import json
import urllib.request
from datetime import datetime, timedelta, timezone
from pathlib import Path

RAIZ = Path(__file__).resolve().parent.parent
CSV_PATH = RAIZ / "data" / "historico.csv"
SAIDA = RAIZ / "docs" / "dados.json"
CAMPOS = ["data", "brent", "cambio", "rbob", "ho",
          "etanol", "gasolina_bomba", "dist_gasolina", "dist_diesel"]
LITROS_BARRIL = 159
LITROS_GALAO = 3.78541
UA = {"User-Agent": "Mozilla/5.0 (painel-combustiveis)"}


# ---------------------------------------------------------------- coleta
def get_json(url):
    req = urllib.request.Request(url, headers=UA)
    with urllib.request.urlopen(req, timeout=30) as r:
        return json.load(r)


def hoje_br():
    return (datetime.now(timezone.utc) - timedelta(hours=3)).date().isoformat()


def yahoo_fechamentos(ticker, janela):
    """Fechamentos diários {data: preço}. Datas no fuso da bolsa."""
    url = f"https://query1.finance.yahoo.com/v8/finance/chart/{ticker}?interval=1d&range={janela}"
    res = get_json(url)["chart"]["result"][0]
    deslocamento = res["meta"].get("gmtoffset", 0)
    fechos = res["indicators"]["quote"][0]["close"]
    saida = {}
    for ts, preco in zip(res["timestamp"], fechos):
        if preco is not None:
            dia = datetime.fromtimestamp(ts + deslocamento, timezone.utc).date().isoformat()
            saida[dia] = round(float(preco), 4)
    return saida


def cambio_serie(dias):
    fim = datetime.now(timezone.utc).date()
    ini = fim - timedelta(days=dias)
    try:
        d = get_json(f"https://api.frankfurter.app/{ini}..{fim}?from=USD&to=BRL")
        return {dia: float(v["BRL"]) for dia, v in d["rates"].items()}
    except Exception:
        lista = get_json(f"https://economia.awesomeapi.com.br/json/daily/USD-BRL/{dias}")
        return {datetime.fromtimestamp(int(i["timestamp"]), timezone.utc).date().isoformat():
                float(i["bid"]) for i in lista}


def coletar_mercado(rows, backfill):
    falhas = []
    janela, dias = ("1y", 365) if backfill else ("10d", 12)
    for campo, ticker in {"brent": "BZ=F", "rbob": "RB=F", "ho": "HO=F"}.items():
        try:
            for dia, v in yahoo_fechamentos(ticker, janela).items():
                rows.setdefault(dia, {"data": dia})[campo] = v
        except Exception as e:
            falhas.append(f"{campo} ({ticker}): {e}")
    try:
        for dia, v in cambio_serie(dias).items():
            rows.setdefault(dia, {"data": dia})["cambio"] = v
    except Exception as e:
        falhas.append(f"cambio: {e}")
    return falhas


def aplicar_manual(rows):
    caminho = RAIZ / "manual.json"
    if not caminho.exists():
        return
    m = json.loads(caminho.read_text(encoding="utf-8"))
    mapa = {"etanol_cepea": "etanol", "gasolina_bomba": "gasolina_bomba",
            "preco_distribuidora_gasolina": "dist_gasolina",
            "preco_distribuidora_diesel": "dist_diesel"}
    linha = rows.setdefault(hoje_br(), {"data": hoje_br()})
    for chave, campo in mapa.items():
        if isinstance(m.get(chave), (int, float)):
            linha[campo] = float(m[chave])


# ------------------------------------------------------------------- csv
def ler_csv():
    if not CSV_PATH.exists():
        return {}
    with open(CSV_PATH, newline="", encoding="utf-8") as f:
        return {r["data"]: {k: (v if k == "data" else (float(v) if v != "" else None))
                            for k, v in r.items()} for r in csv.DictReader(f)}


def gravar_csv(rows):
    CSV_PATH.parent.mkdir(parents=True, exist_ok=True)
    with open(CSV_PATH, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=CAMPOS)
        w.writeheader()
        for dia in sorted(rows):
            w.writerow({k: ("" if rows[dia].get(k) is None else rows[dia][k]) for k in CAMPOS})


# --------------------------------------------------------------- análise
def preparar_serie(rows, cfg):
    """Preenche lacunas (ffill), deriva métricas e descarta dias sem Brent."""
    campos = [c for c in CAMPOS if c != "data"]
    linhas, ultimo = [], {}
    for dia in sorted(rows):
        r = {"data": dia}
        for c in campos:
            v = rows[dia].get(c)
            if v is None:
                v = ultimo.get(c)
            else:
                ultimo[c] = v
            r[c] = v
        linhas.append(r)
    # Só viram "dia de mercado" as datas com Brent de verdade (nada de repetir
    # o preço de ontem em fins de semana ou quando a coleta falhou).
    com_mercado = [r for r in linhas if rows[r["data"]].get("brent") is not None]
    if com_mercado and linhas:
        # os valores manuais mais recentes valem para o último dia de mercado
        for c in ("etanol", "gasolina_bomba", "dist_gasolina", "dist_diesel"):
            com_mercado[-1][c] = linhas[-1][c]
    linhas = com_mercado
    p = cfg["ppi"]
    for r in linhas:
        b, c, rb, ho = r["brent"], r["cambio"], r["rbob"], r["ho"]
        r["brent_rl"] = b * c / LITROS_BARRIL if b and c else None
        r["ppi_gasolina"] = ((rb + p["frete_usd_gal"]) / LITROS_GALAO) * c + p["custos_gasolina_rl"] if rb and c else None
        r["ppi_diesel"] = ((ho + p["frete_usd_gal"]) / LITROS_GALAO) * c + p["custos_diesel_rl"] if ho and c else None
        r["paridade"] = r["etanol"] / r["gasolina_bomba"] * 100 if r["etanol"] and r["gasolina_bomba"] else None
        r["defas_gasolina"] = (r["dist_gasolina"] / r["ppi_gasolina"] - 1) * 100 if r["dist_gasolina"] and r["ppi_gasolina"] else None
        r["defas_diesel"] = (r["dist_diesel"] / r["ppi_diesel"] - 1) * 100 if r["dist_diesel"] and r["ppi_diesel"] else None
    return [r for r in linhas if r["brent"] is not None]


def validos(serie, n=None):
    v = [x for x in serie if x is not None]
    return v[-n:] if n else v


def variacao(serie, n, absoluta=False):
    v = validos(serie)
    if len(v) <= n:
        return None
    ant, atual = v[-1 - n], v[-1]
    return atual - ant if absoluta else (atual / ant - 1) * 100


def media(serie, n):
    v = validos(serie, n)
    return sum(v) / len(v) if len(v) == n else None


def regressao(serie, n=20, horizonte=5):
    v = validos(serie, n)
    if len(v) < 8:
        return None
    m = len(v)
    mx, my = (m - 1) / 2, sum(v) / m
    den = sum((i - mx) ** 2 for i in range(m))
    a = sum((i - mx) * (y - my) for i, y in enumerate(v)) / den
    b = my - a * mx
    return {"inclinacao_dia": a, "valor_projetado": a * (m - 1 + horizonte) + b, "horizonte": horizonte}


def br(x, casas=2):
    return f"{x:.{casas}f}".replace(".", ",")


INDICADORES = [
    ("brent", "Brent", "US$/barril", False),
    ("cambio", "Dólar", "R$", False),
    ("rbob", "Gasolina internacional (RBOB)", "US$/galão", False),
    ("ho", "Diesel internacional (Heating Oil)", "US$/galão", False),
    ("ppi_gasolina", "PPI estimado — gasolina", "R$/L", False),
    ("ppi_diesel", "PPI estimado — diesel", "R$/L", False),
    ("etanol", "Etanol Cepea", "R$/L", False),
    ("paridade", "Paridade etanol/gasolina", "%", True),
]


def decidir_derivado(produto, chave_ppi, chave_defas, ind, ultimo, cfg):
    d = cfg["decisao"]
    v = ind[chave_ppi]["var_5d"]
    if v is None:
        return {"produto": produto, "acao": "Sem dados suficientes", "fator": 1.0,
                "motivo": "Ainda não há histórico para calcular a variação."}
    score, motivos = 0, []
    if v >= d["limiar_pct"]:
        score += 1
        motivos.append(f"O custo de importação estimado subiu {br(v, 1)}% em 5 pregões.")
    elif v <= -d["limiar_pct"]:
        score -= 1
        motivos.append(f"O custo de importação estimado caiu {br(abs(v), 1)}% em 5 pregões.")
    else:
        motivos.append(f"O custo de importação estimado variou {br(v, 1)}% em 5 pregões, dentro da faixa normal.")
    defas = ultimo.get(chave_defas)
    if d["usar_defasagem"] and defas is not None:
        if defas <= -d["defasagem_limite_pct"]:
            score += 1
            motivos.append(f"O preço da distribuidora está {br(abs(defas), 1)}% abaixo da paridade: pressão de reajuste.")
        elif defas >= d["defasagem_limite_pct"]:
            score -= 1
            motivos.append(f"O preço da distribuidora está {br(defas, 1)}% acima da paridade: espaço para queda.")
    if score > 0:
        acao, fator = "Antecipar compra", d["fator_antecipar"]
    elif score < 0:
        acao, fator = "Comprar o mínimo e esperar", d["fator_adiar"]
    else:
        acao, fator = "Compra normal", 1.0
    return {"produto": produto, "acao": acao, "fator": fator, "motivo": " ".join(motivos)}


def decidir_etanol(ultimo, cfg):
    p = ultimo.get("paridade")
    if p is None:
        return {"produto": "Etanol", "acao": "Preencha etanol e gasolina em manual.json", "fator": 1.0,
                "motivo": "Sem preço de etanol ou de gasolina na bomba para calcular a paridade."}
    c = cfg["decisao"]
    if p <= c["paridade_etanol_compensa"]:
        return {"produto": "Etanol", "acao": "Priorizar etanol", "fator": cfg["decisao"]["fator_antecipar"],
                "motivo": f"Paridade em {br(p, 1)}%: o etanol compensa para o consumidor e tende a ganhar volume."}
    if p <= c["paridade_neutra"]:
        return {"produto": "Etanol", "acao": "Equilibrar", "fator": 1.0,
                "motivo": f"Paridade em {br(p, 1)}%: zona neutra entre etanol e gasolina."}
    return {"produto": "Etanol", "acao": "Reduzir etanol", "fator": cfg["decisao"]["fator_adiar"],
            "motivo": f"Paridade em {br(p, 1)}%: a gasolina está mais vantajosa para o consumidor."}


def analisar(rows, cfg, falhas):
    serie = preparar_serie(rows, cfg)
    if not serie:
        return {"atualizado_em": datetime.now(timezone.utc).isoformat(), "falhas": falhas + ["sem dados"],
                "indicadores": [], "decisoes": [], "projecao": [], "series": {"datas": []}}
    ultimo = serie[-1]
    indicadores, projecao, ind = [], [], {}
    for chave, nome, unidade, em_pontos in INDICADORES:
        s = [r[chave] for r in serie]
        m5, m20 = media(s, 5), media(s, 20)
        tend = "—"
        if m5 and m20:
            dif = (m5 / m20 - 1) * 100
            tend = "alta" if dif > 0.5 else "queda" if dif < -0.5 else "estável"
        item = {"id": chave, "nome": nome, "unidade": unidade,
                "valor": validos(s)[-1] if validos(s) else None,
                "var_1d": variacao(s, 1, em_pontos), "var_5d": variacao(s, 5, em_pontos),
                "var_20d": variacao(s, 20, em_pontos), "var_em_pontos": em_pontos, "tendencia": tend}
        indicadores.append(item)
        ind[chave] = item
        if chave in ("brent", "ppi_gasolina", "ppi_diesel"):
            reg = regressao(s)
            if reg:
                projecao.append({"id": chave, "nome": nome, "unidade": unidade, **reg})
    decisoes = [decidir_derivado("Gasolina", "ppi_gasolina", "defas_gasolina", ind, ultimo, cfg),
                decidir_derivado("Diesel", "ppi_diesel", "defas_diesel", ind, ultimo, cfg),
                decidir_etanol(ultimo, cfg)]
    recorte = serie[-180:]
    chaves = ["brent", "cambio", "rbob", "ho", "ppi_gasolina", "ppi_diesel", "etanol",
              "gasolina_bomba", "paridade", "brent_rl"]
    series = {"datas": [r["data"] for r in recorte]}
    for c in chaves:
        series[c] = [None if r[c] is None else round(r[c], 4) for r in recorte]
    return {"atualizado_em": datetime.now(timezone.utc).isoformat(), "ultima_data_mercado": ultimo["data"],
            "falhas": falhas, "indicadores": indicadores, "decisoes": decisoes,
            "projecao": projecao, "series": series}


def main():
    cfg = json.loads((RAIZ / "config.json").read_text(encoding="utf-8"))
    rows = ler_csv()
    falhas = coletar_mercado(rows, backfill=len(rows) < 30)
    aplicar_manual(rows)
    gravar_csv(rows)
    saida = analisar(rows, cfg, falhas)
    ultima = saida.get("ultima_data_mercado")
    if ultima and (datetime.fromisoformat(hoje_br()) - datetime.fromisoformat(ultima)).days > 4:
        saida["falhas"].append(f"dados de mercado defasados (último pregão: {ultima})")
    SAIDA.parent.mkdir(parents=True, exist_ok=True)
    SAIDA.write_text(json.dumps(saida, ensure_ascii=False), encoding="utf-8")
    print(f"OK. Última data de mercado: {saida.get('ultima_data_mercado')}. Falhas: {falhas or 'nenhuma'}")


if __name__ == "__main__":
    main()
